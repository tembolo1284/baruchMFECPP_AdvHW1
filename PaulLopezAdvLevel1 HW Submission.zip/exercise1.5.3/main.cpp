/*a) Create a function that returns the following statistical properties of a numeric vector as a tuple : 
mean, mean deviation, range(the difference between the largest and smallest numbers in the vector), standard deviation and variance.

b) Test the function from part a).In order to make the code more readable you can use tied variablesand std::ignore.

c) Write a function that computes the median of a sorted vector(the median is either the middle value or the arithmetic mean of the two 
middle values) and the mode which is the value that occurs with the greatest frequency. */

#include <vector>
#include <algorithm>
#include <functional>
#include <string_view>
#include <tuple>
#include <iostream>
#include <numeric>

using namespace std;

template <typename T>
static std::tuple<T, T, T, T, T>  StatsCalc(const vector<T>& v) {
		
		T sum = accumulate(v.begin(), v.end(), 0);
		T mean = sum / v.size();
		T mad{ 0 };
		T std = 0;
		T var = 0;
		
		for (int i = 0; i < v.size(); i++) {
			mad = (mad + abs(v[i] - mean));
			var = var + ((v[i] - mean) * (v[i] - mean));
		}
		mad = mad/v.size();
		var = var / v.size();
		std = sqrt(var);
		


		T min = *min_element(v.begin(), v.end());
		T max = *max_element(v.begin(), v.end());
		T range = (max - min);
		
		return std::make_tuple(mean, mad, range, std, var);
	}
template <typename T>
static T ModeFinder(const vector<T>& v) {
	double number = v[0], count = 1, countMode = 1;
	double mode = number;
	for (int i = 1; i < v.size(); i++){
		if (v[i] == number) { // increment the count of curr number's occurrence
			++count;
			if (count > countMode) {
				countMode = count; // this number has most occurrences at the moment
				mode = number; // we have ourselves a new mode!
			}
		}
		else { // different number if we get here
			count = 1; // reset count to 1 for the new number
			number = v[i]; // set the new number
		}
	}
	if (countMode == 1) {
		mode = -1; // set the mode to -1 if each number in the array occur only once
	}
	return mode;
}
template <typename T>
static T MedianFinder(const vector<T>& v) {
	int size = v.size();
		double median{};
		if (size % 2 == 0) { //even
			median = (v[size/2]+v[(size/2)-1]) / 2;
			return median;
		}
		else { //odd
			median = v[(size / 2)];
				return median;
		}

}

using namespace std;

int main() {
	vector<double> v1{ 1.0, 2.0, 3.0, 4.0, 5.0 };

	std::sort(v1.begin(), v1.end());
	tuple<double, double, double, double, double> tup = StatsCalc(v1);

	std::cout << "mu: " << std::get<0>(tup) << endl; //3
	std::cout << "mad: " << std::get<1>(tup) << endl; //1.2
	std::cout << "rng: " << std::get<2>(tup) << endl; //4
	std::cout << "std: " << std::get<3>(tup) << endl; // 1.4142
	std::cout << "var: " << std::get<4>(tup) << endl; // 2

	vector <double> v2{ 1.2, 1.5, 1.5, 2.25, 2.25, 2.257, 2.6, 2.8, 3.0, 3.1, 7.5, 7.5, 7.5, 12.5};
	std::cout << "Vector2: ";
	for (auto i : v2) {
		std::cout << i << ", ";
	}
	std::cout << '\n';
	double median = MedianFinder(v2);
	double mode = ModeFinder(v2);
	cout << "Median: " << median << endl;
	cout << "Mode: " << mode << endl;

	

	return 0;

}