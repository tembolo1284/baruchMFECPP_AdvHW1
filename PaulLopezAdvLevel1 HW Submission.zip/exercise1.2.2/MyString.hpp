#ifndef MyString_HPP
#define MyString_HPP
#include <string>
#include <vector>
#include <cstring>
#include <iostream>
using namespace std;

class MyString {
private:
	string *str;
public:
	MyString(); //default
	MyString(const string *s); //constructor

	MyString(const MyString& ms); //copy constructor
	MyString(MyString&& ms); //move constructor

	~MyString(); //destructor

	MyString& operator = (const MyString &source); //copy assignment
	MyString& operator = (MyString &&source); //move assignment

	const string get_str() const;

};

#endif