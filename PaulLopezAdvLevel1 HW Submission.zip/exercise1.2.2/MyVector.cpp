#include "MyVector.hpp"
#include <iostream>
using namespace std;

MyVector::MyVector() : vec({1.0,2.0,3.0}) { //create a string "Hello" and a vector of 3 doubles
	cout << "Default constructor." << endl;
}

MyVector::MyVector(const MyVector& mv) : vec(mv.vec) {
	cout << "Copy constructor." << endl;
}//copy constructor

MyVector& MyVector::operator = (const MyVector& source) { //copy Assignment operator.
	cout << "This is a copy assignment operator." << endl;
	if (this == &source) {
		return *this;
	}
	vec = source.vec;
	return *this;
}

MyVector& MyVector::operator = (MyVector&& source) { //copy Assignment operator.
	cout << "This is a move assignment operator." << endl;
	if (this == &source) {
		return *this;
	}
	//delete[] *vec;
	vec = source.vec;
	//source.vec = nullptr;
	return *this;
}

MyVector::~MyVector() {
	cout << "Bye Bye my MovePractice Object." << endl;
} //destructor