/*a) Create a string and move it to another string. Check the contents of the source and target strings before and after the move.
b) Create a vector and move it to another vector. Check the contents of the source and target vectors before and after the move. 
Compare the time it takes to move a vector compared to a copy constructor or a copy assignment statement.
c) Consider the following user-defined code to swap two objects:
How many temporary copies are created? 
one copy is made for tmp from a
b is copied to put into a
then copy of tmp is made to put into b.

That's 3 copies of objects. With each vector having 10mm elements in my baby program, we can already tell that's awful.


Now create a function based on move semantics to swap two objects. Compare the 
relative performance of the two swap functions by timing the swap of two very large vectors. Use std::chrono.*/

//moving is obviously faster than copying. Very cool stuff.

#include <string>
#include <vector>
#include <chrono>
#include <iostream>
using namespace std;

template < typename T >
void SwapCopyStyle(T& a, T& b) {
    // Swap a and b in copying way; temporary object needed
    T tmp(a); // Copy constructor
    a = b; // Copy all elements from b to a
    b = tmp; // Copy all elements from tmp to b
}
template < typename T >
void SwapMoveStyle(T& a, T& b) {
    // Swap a and b in copying way; temporary object needed
    T tmp(a); // copy constructor starts the same
    a = std::move(b); // move all elements from b to a
    b = std::move(tmp); // move all elements from tmp to b
}

int main() {
    string str1 = "Hello!";

    std::cout << "Before Move: str1 address is: " << &str1 << " and value is: " << str1 << std::endl;
    string str2 = std::move(str1);
    std::cout << "After Move: str1 address is: " << &str1 << " and value is: " << str1 << std::endl;
    std::cout << "str2 address is: " << &str2 << " and value is: " << str2 << std::endl; 
    // Hello has been taken and put into its own address. How nice.


    vector<double> vec1{ 1.0, 2.0, 3.0 };
    

    std::cout << "\nBefore move: vec1 address is: " << &vec1;
    std::cout << " Values are: ";
    for (int i = 0; i < vec1.size(); i++) {
        std::cout << vec1[i] << " ";
    }
    std::cout << endl;
    auto start = std::chrono::steady_clock::now();

    vector<double> vec2 = std::move(vec1);
    
    auto end = std::chrono::steady_clock::now();
    std::chrono::duration<double> elapsed_seconds = end - start;
    std::cout << "\nelapsed time of vec move: " << elapsed_seconds.count() << "s\n" << std::endl;

    std::cout << "After move: vec1 address is: " << &vec1;
    std::cout << " Values are: ";
    for (int i = 0; i < vec1.size(); i++) {
        cout << vec1[i] << " ";
    }
    cout << endl;

    cout << "After move: vec2 address is: " << &vec2;
    cout << " Values are: ";
    for (int i = 0; i < vec2.size(); i++) {
        cout << vec2[i] << " ";
    }
    cout << endl;
    vector<double> vec3;
    auto start2 = std::chrono::steady_clock::now();
    vec3 = vec1;
    auto end2 = std::chrono::steady_clock::now();
    std::chrono::duration<double> elapsed_seconds2 = end2 - start2;
    std::cout << "\nelapsed time of vector copy assignment operator: " << elapsed_seconds2.count() << "s\n" << std::endl;


    vector<double> big1;
    vector<double> big2;

    //populate two fat vectors
    for (int i = 0; i < 10000000; i++) { //100mm
        big1.push_back(i);
        big2.push_back(-i);
    }

    cout << "big1: " << big1[10] << " " << big2[10] << ": big 2" <<endl; //big1 > 0  , big2 < 0

    auto start3 = std::chrono::steady_clock::now();
    SwapCopyStyle(big1, big2);
    auto end3 = std::chrono::steady_clock::now();
    std::chrono::duration<double> elapsed_seconds3 = end3 - start3;
    std::cout << "\nelapsed time of vector copy swap: " << elapsed_seconds3.count() << "s\n" << std::endl;

    cout << "big1: " << big1[10] << " " << big2[10] << ": big 2" << endl; // now should be big1 < 0  , big2 > 0

    auto start4 = std::chrono::steady_clock::now();
    SwapMoveStyle(big1, big2);
    auto end4 = std::chrono::steady_clock::now();
    std::chrono::duration<double> elapsed_seconds4 = end4 - start4;
    std::cout << "\nelapsed time of vector move swap: " << elapsed_seconds4.count() << "s\n" << std::endl;

    cout << "big1: " << big1[10] << " " << big2[10] << ": big 2" << endl; // back to big1 > 0  , big2 < 0

	return 0;
}