#include "MyString.hpp"
#include <iostream>
using namespace std;

MyString::MyString() : str{nullptr} { //create a string "Hello"
	cout << "Default constructor." << endl;
	str = new string;
	*str = '\0';
}

MyString::MyString(const string *s) : str{nullptr} { //create a MyString instance with string s
	cout << "Constructor with string." << endl;
	if (s == nullptr) {
		str = new string;
		*str = '\0';
	}
	else {
		str = new string;
		*str = *s;
	}
}

MyString::MyString(const MyString& ms) : str{ nullptr } {
	cout << "Copy constructor used." << endl;
	str = new string;
	str = ms.str;
}//copy constructor

MyString::MyString(MyString&& ms) : str(ms.str)  {
	ms.str = nullptr;
	cout << "Move constructor used." << endl;
}//move constructor

MyString& MyString::operator = (const MyString& source) { //copy Assignment operator.
	cout << "This is a copy assignment operator." << endl;
	if (this == &source) {
		return *this;
	}
	delete[] str;
	str = new string;
	str = source.str;
	return *this;
}

MyString &MyString::operator = (MyString &&source) { //move Assignment operator.
	std::cout << "This is a move assignment operator." << std::endl;
	if (this == &source) {
		return *this;
	}
	delete[] str;
	str = new string;
	str = source.str;
	source.str = nullptr; //can't forget to make original source rh ref point to nullptr or I'm going to be in a world of hurt
	return *this;
}

MyString::~MyString() {
	if (str == nullptr) {
		cout << "Bye bye my nullptr MyString Object." << endl;
	}
	else {
		cout << "Bye bye my MyString Object." << endl;
	}
} //destructor

const string MyString::get_str() const {
	return *str;
}