#ifndef MyVector_HPP
#define MyVector_HPP
#include <string>
#include <vector>
#include <iostream>
using namespace std;

class MyVector {
private:
	vector<double> vec;
public:
	MyVector(); //default
	MyVector(const MyVector& mv); //copy constructor
	MyVector(MyVector&& mv); //move constructor
	~MyVector(); //destructor

	MyVector& operator = (const MyVector& source); //copy assignment
	MyVector& operator = (MyVector&& source); //move assignment




};

#endif