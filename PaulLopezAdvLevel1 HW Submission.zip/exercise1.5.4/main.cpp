#include <iostream>
#include <algorithm>
#include <vector>
#include <iterator>
using namespace std;

template <typename T>
static T Finder(const vector<T>& v, T n) {
	auto result = std::find(begin(v), end(v), n);
	if (result != end(v)) {
		return std::distance(begin(v), result);
	}
	else {
		return std::distance(v.begin(), v.end());
	}
}
// z = x -y = [x1-y1, x2-y2, ..., xn-yn], ||z|| = [|z1|, |z2|, ..., |zn|]

template <typename T>
static T MaxNormFinder(const vector<T>& x, const vector<T>& y, int start, int end) {
	vector<T> z;
	T result;
	if (x.size() != y.size() || start > end) {
		std::cout << "Input to function is invalid." << std::endl;
	}
	else {
		for (int i = start-1; i < end; i++) {
			z.push_back(abs(x[i] - y[i])); //vector of abs value of diffs just over range specified. 
		}

	}
	result = *max_element(z.begin(), z.end()); //do a max element over smaller subvector to get result
	return result;
}


int main() {
	double n = 4.5;
	vector<double> v1{1.0, 2.5, 3.5, 4.5, 6.0, 10.0, 11.25 };
	vector<double> v2{2.5, 3.5, 4.0, 4.25, 5.0, 7.5, 10.5};

	double index = Finder(v1,n);
	std::cout << "Index of vector is: " << index << std::endl;
	
	double maxDiff = MaxNormFinder(v1, v2, 2, 6);
	std::cout << "Max norm element of vectors in specified range is: " << maxDiff << std::endl;

	return 0;

}



