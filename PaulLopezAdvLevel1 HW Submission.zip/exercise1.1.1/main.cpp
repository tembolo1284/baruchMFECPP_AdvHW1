#include <algorithm>
#include <iostream>
#include <numeric>
#include <vector>
using namespace std;

int main() {
    /*
    a) Create a lambda function that multiplies each element of an array by a number.This number is a captured variable;
    test the function for the cases when it is copy - by - value and a reference.The original array is modified after having 
    called the function.*/

	vector<double> v1 = { 5.0, 2.0, 3.0 };
    vector<double> v2 = { 4.5, 11.25, 1.125, 8.5, 0.125, 2.75, 0.05};
    double num{ 2.0 };
    auto f1 = [=](double i) {
        i *= num;
        return i; };

    auto f2 = [&](double i) {
        i *= num;
        return i; };

    vector<double>::const_iterator iter;
    for (iter = v1.cbegin(); iter != v1.cend(); iter++) {
       cout << f1(*iter) << " ";
    }
    //cout << "After f1 function: ";
    //cout << v1[0] << " " << v1[1] << " " << v1[2] << endl;
    std::cout << endl;
    for (iter = v2.cbegin(); iter != v2.cend(); iter++) {
       cout << f2(*iter)<<" ";
    }
    //cout << "After f2 function: ";
    //cout << v2[0] << " " << v2[1] << " " << v2[2] << endl;
    std::cout << endl;
   
//b) Print the values of the modified array using auto to initialize the iterator variable instead of declaring it explicitly.
    std::cout << "First Vec: ";
    for (auto it = v1.begin(); it < v1.end(); it++) {
        std::cout << *it<< " ";
    }
    std::cout << endl;
    std::cout << "Second Vec: ";
    for (auto it = v2.begin(); it < v2.end(); it++) {
        std::cout <<f2(*it) << " ";
    }
    cout << " <--- it changed wooo!" << endl;
/*c) Write a lambda function to compute both the minimum and maximum of the elements in an array.The return type is an std::pair(or if you prefer,
std::tuple with two elements) containing the computed minimum and maximum values in the array.*/
    pair<double, double> pair1;
    pair1.first = v1[0];
    pair1.second = v1[1];
   //beginning of my minMaxer lambda
    auto MinMaxer = [&](const vector<double>& v) -> pair<double, double> {
        double min = v[0];
        double max = v[1];
        vector<double>::const_iterator i;
        for (i = v.begin(); i != v.end(); i++) {
            min = [&]() -> double { return *i < min ? *i : min; }();
            max = [&]() -> double { return *i > max ? *i : max; }();
        }
        pair1.first = min;
        pair1.second = max;
        return pair1;
    };//end of minMaxer lambda.  It's two lambdas in a lambda and it seems odd.  I blame my python scar tissue :)

    auto pairMinMax = MinMaxer(v2);
    cout << "Min Element: " << pair1.first << " Max Element: " << pair1.second << endl;


/*d) Compare the approach taken in part c) by calling std::minmax_element. For example, do you get the same output ? 
How easy is to understand and reuse the code ?*/
    

    auto minMaxResult = std::minmax_element(v2.begin(), v2.end());

    std::cout << "min is: " << *minMaxResult.first << "   max is: " << *minMaxResult.second;
 

 //the minmax_element is literally a line of code. My code is a car crash compared to it :D 
 //Super easy to re-use the minmax_element() code I think!  Output is the same thankfully!

    return 0;
}