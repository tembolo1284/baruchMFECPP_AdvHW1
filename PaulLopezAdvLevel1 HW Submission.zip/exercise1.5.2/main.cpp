/*a) Create a template class with static member functions to compute the maximum, sum and average of the
elements in the tuple.
b) Test the code on tuples with two and three elements whose underlying type is double.
c) Compute the sum and average of a tuple whose element type is std::complex<int>. */
#include <iostream>
#include <tuple>
#include <complex>
using namespace std;

template <typename T, typename Tuple, std::size_t index>
struct Calculator {

	static T Max(const Tuple& tup) {
		T tmp = Calculator<T, Tuple, index - 1>::Max(tup);
		//std::cout << ", " << std::get<index - 1>(tup);
		tmp = std::max(get<index - 1>(tup), get<index - 2>(tup));
		//std::cout << std::endl << "Sum is: " << tmp << std::endl;
		return tmp;
	}

	static T Sum(const Tuple& tup) {
		T tmp = Calculator<T, Tuple, index - 1>::Sum(tup);
		//std::cout << ", " << std::get<index - 1>(tup);
		tmp += std::get<index - 1>(tup);
		//std::cout << std::endl << "Sum is: " << tmp << std::endl;
		return tmp;
	}
	
	static T Avg(const Tuple& tup) {
		T avgTmp = Calculator<T, Tuple, index-1>::Sum(tup);
		//std::cout << ", " << std::get<index - 1>(tup);
		avgTmp += std::get<index - 1>(tup);
		avgTmp = avgTmp / static_cast<double>(index);
		//std::cout << std::endl << "Avg is: " << avgTmp << std::endl;
		return avgTmp;
	}
};

template <typename T, typename Tuple>
struct Calculator<T, Tuple, 1> {
	
	static T Sum(const Tuple& tup) {
		//std::cout << std::get<0>(tup);
		T tmp = std::get<0>(tup);
		return tmp;
	}

	static T Max(const Tuple& tup) {
		//std::cout << ", " << std::get<index - 1>(tup);
		T tmp = std::max(get<0>(tup), get<1>(tup));
		//std::cout << std::endl << "Sum is: " << tmp << std::endl;
		return tmp;
	}
};



int main() {
	std::tuple<double, double> Example = std::make_tuple(2.5, 1.5);
	std::tuple<double, double, double> Example2 = std::make_tuple(1.5, 2.0, 5.5);
	const int N1 = std::tuple_size<decltype(Example)>::value;
	const int N2 = std::tuple_size<decltype(Example2)>::value;

	double calcMax = Calculator<double, std::tuple<double, double>, N1>::Max(Example); //2.5
	double calcSum = Calculator<double, std::tuple<double, double>, N1>::Sum(Example); //4
	double calcAvg = Calculator<double, std::tuple<double, double>, N1>::Avg(Example); //2
	std::cout << "Original tuple: " << get<0>(Example) << " " << get<1>(Example) << std::endl;
	std::cout << "Max is: " << calcMax << std::endl;
	std::cout << "Sum is: " << calcSum << std::endl;
	std::cout << "Avg is: " << calcAvg << std::endl;

	double calcMax2 = Calculator<double, std::tuple<double, double, double>, N2>::Max(Example2); //5.5
	double calcSum2 = Calculator<double, std::tuple<double, double, double>, N2>::Sum(Example2); //8.5
	double calcAvg2 = Calculator<double, std::tuple<double, double,double>, N2>::Avg(Example2); //4.25
	std::cout << "\nOriginal tuple: " << get<0>(Example2) << " " << get<1>(Example2) << " " << get<2>(Example2) << std::endl;
	std::cout << "Max is: " << calcMax2 << std::endl;
	std::cout << "Sum is: " << calcSum2 << std::endl;
	std::cout << "Avg is: " << calcAvg2 << std::endl;
	
	complex<double> c1(1.0, -2.0);
	complex<double> c2(2.5, 3.0);
	std::tuple<complex<double>, complex<double>> complexTup;
	std::get<0>(complexTup) = c1;
	std::get<1>(complexTup) = c2;

	complex<double> complexSum = Calculator<complex<double>, std::tuple<complex<double>, complex<double>>, N1>::Sum(complexTup);//c1 + c2 = (3.5,1)
	complex<double> complexAvg = Calculator<complex<double>, std::tuple<complex<double>, complex<double>>, N1>::Avg(complexTup);//avg = (1.75,0.5)
	std::cout << "c1 and c2: (" << get<0>(complexTup) << "," << get<1>(complexTup) << ")" << std::endl;//kinda cheated and displayed basically as a point versus a + bi notation. :)
	std::cout << "Complex Sum is: " << complexSum << std::endl;
	std::cout << "Complex Avg is: " << complexAvg << std::endl;
	



	return 0;

}