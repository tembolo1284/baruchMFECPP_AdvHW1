#include "ClassC.hpp"
#include <vector>
#include <iostream>
using namespace std;

ClassC::ClassC() : vec({ 1.0,2.0,3.0 }) { //create a vector of 3 doubles
	cout << "Default constructor." << endl;
}

ClassC::ClassC(const ClassC& c) : vec(c.vec) {
	cout << "Copy constructor." << endl;
}//copy constructor

ClassC& ClassC::operator = (const ClassC& source) { // Assignment operator.

	if (this == &source) {
		return *this;
	}
	vec = source.vec;
	cout << "This is an assignment operator." << endl;
	return *this;
}

ClassC::~ClassC() {
	cout << "Bye Bye ClassC." << endl;
} //destructor

ClassC& ClassC::operator * (const double factor) {  // Scale the coordinates.
	vector<double> v;
	for (int i = 0; i < vec.size(); i++) {
		v.push_back(vec[i] * factor);
	}
	vec = v;
	return *this;
}

void ClassC::print() {
	cout << "\nElements of vector: ";
	for (int i = 0; i < vec.size(); i++) {
		cout << vec[i] << " ";
	}
	cout << endl;
}