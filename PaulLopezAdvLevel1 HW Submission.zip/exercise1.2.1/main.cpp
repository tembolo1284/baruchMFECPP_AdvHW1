/*First, you need to create a class (call it C) with an instance of std::vector as data member. Create public default
constructor, copy constructor, assignment operator and destructor. Test the code. Place print statements in the bodies of
each member function to show that it has been called. Furthermore, create some member functions (for example a print()
function or a modifier function to scale(double) the values in C�s data member) that you know will not throw an exception.
This class will now be used as input in this exercise. You should spend some time on these exercises until you understand
the bespoke core features.*/

#include "ClassC.hpp"
#include <iostream>
using namespace std;

int main() {

	ClassC C1; //default constructor
	ClassC C2(C1); // copy constructor
	ClassC C3;
	double num{ 5.0 };
	cout << "Vector before scalar mult: ";
	for (int i = 0; i < C1.vec.size(); i++) {
		cout << C1.vec[i] << " ";
	}
	cout << endl;
	C1 * num;
	cout << "Vector after scalar mult: ";
	for (int i = 0; i < C1.vec.size(); i++) {
		cout << C1.vec[i] << " "; // should spit out 5 10 15
	}
	cout << endl;
	//print statement
	C1.print();
	C2.print();
	cout << endl;

	ClassC C4; 
	C4 = C2 * num; //assignment operator
	C4.print();

	return 0;

}