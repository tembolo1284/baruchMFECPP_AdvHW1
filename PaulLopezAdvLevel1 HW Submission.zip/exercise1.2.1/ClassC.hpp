
#ifndef ClassC_hpp
#define ClassC_hpp
#include <vector>
using namespace std;

class ClassC {
	
public:
	vector<double> vec; //vector data member

	ClassC(); //default constructor
	ClassC(const ClassC& c); //copy constructor
	~ClassC(); //destructor
	ClassC& operator = (const ClassC& source); //assignment
	void print(); //print
	ClassC& operator * (const double factor); //scalar mult of vector data member
};


#endif
