#include <iostream>
#include <sstream>
#include <iomanip>
#include <cstddef>
#include <bitset>
#include <span>
#include "boost/date_time/gregorian/gregorian.hpp"
#include <tuple>
using namespace std;

template <int index> 
struct TupleSorter {
    template <typename Tuple> 
    bool operator () (const Tuple& left, const Tuple& right) const {
        return std::get<index>(left) < std::get<index>(right);
    }
};

template <typename Tuple, std::size_t index> 
struct TuplePrint {
    static void PrintSpan(const Tuple& tup) {
        TuplePrint<Tuple, index - 1>::PrintSpan(tup);
        std::cout << ", " << std::get<index - 1>(tup);
    }
   /*
    static void PrintSpanFor(const Tuple& tup) {
        for (auto i : tup) {
            std::cout << i << " ";
        }
    }

    static void PrintSpanIter(const Tuple& tup) {
        for (auto i = tup.begin(), i != tup.end(), i++) {
            std::cout << get<i>(tup) << " ";
        }
    }
    */
};

template <typename Tuple>
struct TuplePrint<Tuple,1> {
    static void PrintSpan(const Tuple& tup) {
        std::cout << std::get<0>(tup);
    }
};

template <typename Tuple, std::size_t... Index>
void printTupleImp(const Tuple& tup, std::index_sequence<Index...>) {
    size_t N = 0;
    auto printElem = [&N](const auto& x) {
        if (N++ > 0)
            std::cout << ", ";
        std::cout << x;
    };

    (printElem(std::get<Index>(tup)), ...);
}

template <typename Tuple, std::size_t TupSize = std::tuple_size_v<Tuple>>
void printTuple(const Tuple& tup) {
    printTupleImp(tup, std::make_index_sequence<TupSize>{});
}

void simpleTuplePrint(std::tuple<std::string, std::string, boost::gregorian::date> tup) {
    std::cout << std::get<0>(tup) << ", " << std::get<1>(tup) << ", " << std::get<2>(tup) << std::endl;
}


void PrintSpanTweak(std::span<double> container) {
    for (auto i : container) {
        i += 3;
        std::cout << i << " ";
    }
    std::cout << endl;
}
void PrintSpanFor(std::span<double> container) {
    for (auto i : container) {
        std::cout << i << " ";
    }
    std::cout << endl;
}

void PrintSpanIter(std::span<double> container) {
    for (auto i = container.begin(); i != container.end(); i++) {
        std::cout << *i << " ";
    }
    std::cout << endl;
}

void PrintSpanIndex(std::span<double> container) {
    int size = container.size();
    for (int i = 0; i < size; i++) {
        std::cout << container[i] << " ";
    }
    std::cout << endl;
}

void PrintSpanSubspan(std::span<double> container, int offset, int count) {
    int size = container.size();
    if (offset > size || (offset + count) > size) {
        std::cout << "You entered incorrect parameters." << endl;
    }
    else {
        for (int i = offset; i < (offset + count); i++) {
            std::cout << container[i] << " ";
        }
    }
    std::cout << endl;
}

void PrintSpanFirstN(std::span<double> container, int N) {
    for (int i = 0; i < N; i++) {
        std::cout << container[i] << " ";
    }
    std::cout << endl;
}

void PrintSpanLastN(std::span<double> container, int N) {
    int size = container.size();
    for (int i = (size-N); i < size; i++) {
        std::cout << container[i] << " ";
    }
    std::cout << endl;
}

auto ByteViewSpan(const auto& spanBytes) {
    std::cout << "--------------Byte View start.-------------" << std::endl;
    for (auto const i : spanBytes) {
        // display the byte view
        std::cout << std::setw(4) << std::hex << std::uppercase << std::setfill('*') << std::to_integer<int>(i) << std::endl;
        //std::cout << "Binary rep: " << std::bitset<8>{i};
    }
    std::cout << "--------------Byte View complete.-------------" << std::endl;
}

int main() {
    using namespace boost::gregorian;
    //a) Create a tuple that models some attributes of a Person consisting of a name, address(both std::string) 
    //and date of birth(as a Boost date).Create some instances of Personand modify their elements.'
    date dob(1984, Dec, 7);
    date dob2(1953, Jan, 15);
    date dob3(2000, Jun, 1);
    std::tuple<string, string, date> Example = std::make_tuple("Gilberto", "1 Main Street", dob);
    std::tuple<string, string, date> Example2 = std::make_tuple("Johnny", "223 Madison Ave", dob2);
    tuple<string, string, date> Example3 = std::make_tuple("Bobby", "37 Broadway", dob3);
    
    //b) Create a function to print the elements of Examples.
    std::cout << std::get<0>(Example) << ", " << std::get<1>(Example) << ", " << std::get<2>(Example) << std::endl;
    std::cout << "Simple tuple print: ";
    simpleTuplePrint(Example2);
    

    //c) Create a list / vector of Person and add some instances of Person to it.
    using Person = std::tuple<std::string, std::string, boost::gregorian::date>;

    vector<Person> manyHumans;
    manyHumans.push_back(Example);
    manyHumans.push_back(Example2);
    manyHumans.push_back(Example3); //is there a nice/clever way to display this guy? 

   //d) Write a function to sort the list based on one of the elements(for example, we can sort by name, address or date of birth).
   
    std::sort(manyHumans.begin(), manyHumans.end(), TupleSorter<0>()); //sorting on first index (string) in this example.
   
   
   //e) Create fixed - sized and variable - sized arrays and create span views of them. Are these views read - only ? 
   // Prove or disprove this question.  
    //It is read-only for me. I can change the contents of the vec as seen below with PrintSpanTweak where I multiply each 
    //element by 3, but I can't use by reference param, so my changes won't stick. It doesn't even compile.

    vector<double> vec = { 1.0, 2.0, 3.0, 4.0, 5.0 };
    std::cout << "Quick vector transform: ";
    PrintSpanTweak(vec); //add 3 to each element

    std::cout << "Original vector: ";
    PrintSpanFor(vec);
    

   //f) Create 3 print functions for spans using a) range - based for loops, b) iterators and c) indexing operator [].
   
    std::cout << "Range based for loop: ";
    PrintSpanFor(vec);
   
    std::cout << "Iterator method: ";
    PrintSpanIter(vec);

    std::cout << "indexing operator method: ";
    PrintSpanIndex(vec);


   //g) Write functions to return the first and last N elements of a span.
    const int N = 2;
    std::cout << "First " << N << ": ";
    PrintSpanFirstN(vec, N);

    std::cout << "Last " << N << ": ";
    PrintSpanLastN(vec, N);

   //h) Write a function to test std::subspan.
    std::cout << "Subspan test: ";
    PrintSpanSubspan(vec, 2, 2);


    //i) Investigate and extend the following code to create �byte views of spans� :
    /*std::cout << "\n-------------Byte View of Spans-------------\n";
    float data[1]{ 3.141592f };
    auto const const_bytes = std::as_bytes(std::span{ data });
    for (auto const b : const_bytes) {
        //std::cout << std::setw(2) << endl;
        //std::cout << std::hex << 42 << endl;
       // std::cout << std::uppercase << endl;
        //std::cout << std::setfill('0') << endl;
        //std::cout << std::to_integer<int>(b) << endl;
    } */

    //some examples
    char charData[3]{ 'A','%', '+' };
    int intData[3]={ 555,777,5757 };
    float floatData[3]{ 3.141592f,5.1234758f, 7.5555875f };
    
    auto const CharWritable_bytes = std::as_writable_bytes(std::span{ charData });
    auto const IntWritable_bytes = std::as_writable_bytes(std::span{ intData });
    auto const FltWritable_bytes = std::as_writable_bytes(std::span{ floatData });
    

    ByteViewSpan(CharWritable_bytes);
    ByteViewSpan(IntWritable_bytes);
    ByteViewSpan(FltWritable_bytes);
    
	return 0;
}