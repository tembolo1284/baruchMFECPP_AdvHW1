#include <iostream>
#include <functional>
using namespace std;
using namespace std::placeholders;
// Class hierarchy
class Shape {
protected:
	using VoidFunctionType = std::function<void(double)>;
	VoidFunctionType fShape; 
public:
	virtual void rotate(VoidFunctionType& f, double d) = 0;
	Shape() {} //boring default constructor

	Shape(double d) { 
		rotate(fShape, d);
	}
};

class Circle : public Shape { //derived from shape

protected:
	using VoidFunctionType = std::function<void(double)>;
	VoidFunctionType fCircle; 

public:
	void rotate(VoidFunctionType& f, double d) override { std::cout << "circle\n"; }
	Circle(double d) {
		rotate(fCircle, d);
	}

};

class Line : public Shape { //derived from shape
protected:
	using VoidFunctionType = std::function<void(double)>;
	VoidFunctionType fLine; 

public:
	void rotate(VoidFunctionType& f, double d) override { std::cout << "line\n"; }
	Line(double d) {
		rotate(fLine, d);
	}
};


struct RandomClass { // Function object with extra member functions and data
	double _data;
	RandomClass(double data) : _data(data) {
	}
	double operator () (double factor) {
		return _data + factor;
	}
	double OneParam(double factor) {
		return _data + factor;
	}
	double TwoParam(double factor1, double factor2) {
		return _data + factor1 + factor2;
	}
	static double DoIt(double x) {
		return x * x;
	}
	void print() const {
		std::cout << _data;
	}
};

class C { // Function object with extra member functions
private:
	double _data;
public:
	C(double data) : _data(data) {}
	double operator () (double factor) {
		return _data + factor;
	}

	double translate(double factor) {
		return _data + factor;
	}

	double translate2(double factor1, double factor2) {
		return _data + factor1 + factor2;
	}

	static double Square(double x) {
		return x * x;
	}
};

template <typename T>
using FunctionType = std::function<T(const T& t)>;

template <typename T>
void print(const FunctionType<T>& f, T t) {
	std::cout << f(t) << '\n';
}

double freeFn(double d){
	return (d * d);
}

double freeFunction3(double x, double y, double z) {
	return (x + y + z);
}

int main() {
	using namespace std::placeholders; 
	
	using VoidFunctionType = std::function<void(double)>;
	VoidFunctionType fExternal; // for _1, _2, _3...
	
	double d1{ 1.0 };
	double d2{ 2.0 };
	double d3{ 3.0 };
	Circle c1(d1); //using protected built-in f
	Line l1(d2);
	c1.rotate(fExternal, d1); //using main() created f to run rotate.
	

							  /*a) Bind the function wrapper to C�s static member function.
	b) Bind the function wrapper to C�s member functions using std::bindand placeholders.
	c) Test the function.*/
	
	
	//auto f_0 = std::bind(&freeFunction3,0,0,0);
	//auto f_1 = std::bind(&freeFunction3, _1, 0, 0);
	//auto f_2 = std::bind(&freeFunction3, _1, _2, 0);
	//auto f_3 = std::bind(&freeFunction3, _1, _2, _3);
	/*
	FunctionType<double> fSquare = std::bind(C::Square, _1);
	print(fSquare, 2.0);

	C c1(10.0);
	FunctionType<double> fTranslate = std::bind(&C::translate, c1, _1);
	print(fTranslate, -1.125);

	FunctionType<double> fTranslate2 = std::bind(&C::translate2, c1, _1, 3.0);
	print(fTranslate2, -2.5);
	*/
	/*
	double result0 = f_0();
	double result1 = f_1(d1);
	double result2 = f_2(d1, d2);
	double result3 = f_3(d1, d2, d3);
	std::cout << result0 << std::endl; // 0
	std::cout << result1 << std::endl; // 1
	std::cout << result2 << std::endl; // 3
	std::cout << result3 << std::endl; // 6 */
		
	return 0;
}
