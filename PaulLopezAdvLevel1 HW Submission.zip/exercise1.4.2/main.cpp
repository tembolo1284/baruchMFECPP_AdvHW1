#include <iostream>
#include <functional>
using namespace std;

struct RandomClass { // Function object with extra member functions and data
	double _data;
	RandomClass(double data) : _data(data) {
	}
	double operator () (double factor) {
		return _data + factor;
	}
	double OneParam(double factor) {
		return _data + factor;
	}
	double TwoParam(double factor1, double factor2) {
		return _data + factor1 + factor2;
	}
	static double DoIt(double x) {
		return x * x;
	}
	void print() const {
		std::cout << _data;
	}
};

template <typename T>
using FunctionType = std::function<T(const T& t)>;

template <typename T>
void print(const FunctionType<T>& f, T t) {
	std::cout << f(t) << '\n';
}

double freeFn(double d){
	return (d * d);
}

double freeFunction3(double x, double y, double z) {
	return (x + y + z);
}

int main() {
	using namespace std::placeholders;  // for _1, _2, _3...
	
	double d1{ 1.0 };
	double d2{ 2.0 };
	double d3{ 3.0 };
	auto f_0 = std::bind(&freeFunction3,5,5,5);
	auto f_1 = std::bind(&freeFunction3, _1, 0, 0);
	auto f_2 = std::bind(&freeFunction3, _1, _2, 0);
	auto f_3 = std::bind(&freeFunction3, _1, _2, _3);

	double result0 = f_0();
	double result1 = f_1(d1);
	double result2 = f_2(d1, d2);
	double result3 = f_3(d1, d2, d3);
	

	std::cout << result0 << std::endl; // 15
	std::cout << result1 << std::endl; // 1
	std::cout << result2 << std::endl; // 3
	std::cout << result3 << std::endl; // 6
		
	return 0;
}
