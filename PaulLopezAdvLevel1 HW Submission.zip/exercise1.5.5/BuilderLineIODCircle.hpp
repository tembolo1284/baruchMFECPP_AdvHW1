#ifndef BUILDERLINEIODCIRCLE_HPP
#define BUILDERLINEIODCIRCLE_HPP
#include "Shape.hpp"
#include "IODevice.hpp"
#include "IODeviceCircle.hpp"
#include "IODeviceLine.hpp"
#include "Builder.hpp"
#include <memory>
#include <tuple>

using ShapePointer = std::shared_ptr<Shape>;
using IODevicePointer = std::shared_ptr<IODevice>;

class Line;
class Circle;
class BuilderLineIODCircle : public Builder {
    // A Builder hierarchy that builds shapes and io devices
public:
    std::tuple<ShapePointer, IODevicePointer> getProduct() {
        // GOF (!) Template Method pattern
        return std::make_tuple(getShape(), getIODevice());

    }
    // Hook functions that derived classes must implement
    ShapePointer getShape() {

        ShapePointer l1 = std::make_shared<Line>();
        return l1;

    }

    IODevicePointer getIODevice() {
        IODevicePointer iodC = std::make_shared<IODeviceCircle>();
        return iodC;
        //return IODevicePointer;
    }

};

#endif