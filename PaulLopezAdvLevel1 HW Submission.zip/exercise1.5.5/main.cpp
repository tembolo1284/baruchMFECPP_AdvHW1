#include <iostream>
#include <stdio.h>
#include "Shape.hpp"
#include "IODevice.hpp"
#include "IODeviceCircle.hpp"
#include "IODeviceLine.hpp"
#include "Builder.hpp"

#include "BuilderCircleIODCircle.hpp"
#include "BuilderCircleIODLine.hpp"
#include "BuilderLineIODLine.hpp"
#include "BuilderLineIODCircle.hpp"
using namespace std;

int main() {
    //part 1
    Circle c1;
    Line l1;
    IODeviceCircle ioDeviceCircle;
    IODeviceLine ioDeviceLine;
    c1.display(ioDeviceCircle);
    l1.display(ioDeviceLine);
    ioDeviceCircle << c1;
    ioDeviceLine << l1;
    //part 2
    

    //ShapePointer circ;
    //ShapePointer line;
    //IODevicePointer iodC;
    //IODevicePointer iodL;

    BuilderCircleIODCircle CiodC; //need 4 builders to take into account all permutations C iodCircle, L iodCircle, C iodLine, L iodLine
    BuilderCircleIODLine CiodL;// or more generally shape1 iod1, shape2 iod1, shape1 iod2, shape2 iod2
    BuilderLineIODCircle LiodC;
    BuilderLineIODLine LiodL;
    
    tuple<ShapePointer, IODevicePointer> tupCiodC = CiodC.getProduct();
    tuple<ShapePointer, IODevicePointer> tupLiodC = LiodC.getProduct();
    tuple<ShapePointer, IODevicePointer> tupCiodL = CiodL.getProduct();
    tuple<ShapePointer, IODevicePointer> tupLiodL = LiodL.getProduct();

    ShapePointer circ = get<0>(tupCiodC);
    ShapePointer line = get<0>(tupLiodC);
    IODevicePointer iodC = get<1>(tupCiodC);
    IODevicePointer iodL = get<1>(tupCiodL);

    std::cout << "\nPrinting through Builders:" << endl;
    (*circ).display(*iodC); //circle through circle IO Device
    (*circ).display(*iodL); // circle through line IO Device
    (*line).display(*iodC); // line through circle IO Device
    (*line).display(*iodL); // line through line IO Device

    std::cout << "\nPrinting through Overloading through Builders:" << endl;
    (*iodC) << (*circ);
    (*iodC) << (*line);
    (*iodL) << (*circ);
    (*iodL) << (*line);

    return 0;
}