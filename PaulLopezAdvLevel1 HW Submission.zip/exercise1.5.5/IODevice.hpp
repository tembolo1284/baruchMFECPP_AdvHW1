#ifndef IODEVICE_HPP
#define IODEVICE_HPP
#include "Shape.hpp"

//class Shape; //fwd declare shape class

class IODevice {
    // Interface for displaying CAD objects
public:
    virtual void operator << (const Shape& s) = 0; //sir Avi with the save to add shape op overload
    virtual void operator << (const Line& l) = 0;
    virtual void operator << (const Circle& c) = 0;
    
    
};


#endif