#ifndef SHAPE_HPP
#define SHAPE_HPP

class IODevice;

class Shape {
public:
    virtual void display(IODevice& ioDevice) const = 0;
};

class Circle : public Shape {
public:
     void display(IODevice& ioDevice) const {
         std::cout << "Print Circle through display." << std::endl;
    }
};

class Line : public Shape {
public:
    void display(IODevice& ioDevice) const {
        std::cout << "Print Line through display." << std::endl;
    }
};

#endif