#ifndef IODEVICECIRCLE_HPP
#define IODEVICECIRCLE_HPP
#include <iostream>
#include "IODevice.hpp"

class IODeviceCircle : public IODevice {
    // Interface for displaying CAD objects
public:

    void operator << (const Shape& s) {
        s.display(*this);
        //std::cout << "Print line through IODevice" << std::endl;
    }
    void operator << (const Line& l) {
        l.display(*this);
        //std::cout << "Print line through IODevice" << std::endl;
    }
    void operator << (const Circle& c) {
        c.display(*this);
        //std::cout << "Print circle through IODevice" << std::endl;
    }

};

#endif