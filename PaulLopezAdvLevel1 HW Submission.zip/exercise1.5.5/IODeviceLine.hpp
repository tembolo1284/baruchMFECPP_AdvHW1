#ifndef IODEVICELINE_HPP
#define IODEVICELINE_HPP
#include <iostream>
#include "IODevice.hpp"

class Circle;
class Line;

class IODeviceLine : public IODevice {
    // Interface for displaying CAD objects
public:

    void operator << (const Shape& s) {
        //std::cout << "Print circle through IODevice" << std::endl;
        s.display(*this);
    }

    void operator << (const Circle& c) {
        //std::cout << "Print circle through IODevice" << std::endl;
        c.display(*this);
    }

    void operator << (const Line& l) {
        l.display(*this);
        //std::cout << "Print line through IODevice" << std::endl;
    }

};

#endif