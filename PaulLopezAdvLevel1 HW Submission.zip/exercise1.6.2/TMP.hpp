#ifndef TMP_HPP
#define TMP_HPP
#include <iostream>
#include <functional>
#include <vector>
#include<algorithm>
using namespace std;

using InputFunction = std::function<double()>;
using OutputFunction = std::function<void(const std::vector<double>&)>;


class TMP final { //no deriving from this class
private:
	std::vector<double> m_v;
	InputFunction m_iFunc;
	OutputFunction m_oFunc;

public:
	TMP(std::size_t n, double startVal, InputFunction iF, OutputFunction oF) {
		std::vector<double> vec(n);
		for (int i = 0; i < n;i++) {
			vec[i] = (startVal);
		}
		m_v = vec;
		m_iFunc = iF;
		m_oFunc = oF;
	}

	void computation() {
		std::transform(m_v.begin(), m_v.end(), m_v.begin(), [this](double& d) {
			
			return d * m_iFunc();
			});
		std::cout << "\n";
		m_oFunc(m_v);//output vector right after scalar mult transform
	}

	void print() {
		std::cout << "\n";
		for (auto i : m_v) {
			std::cout << i << " ";
		}
	}

};




#endif