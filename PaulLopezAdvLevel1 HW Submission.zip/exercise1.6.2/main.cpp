#include <iostream>
#include "TMP.hpp"
using InputFunction = std::function<double()>;
using OutputFunction = std::function<void(const std::vector<double>&)>;

//double InputFunc1() {
	
double InputFunc1() {
	return 3.0;
}

void OutputFunc1(const std::vector<double>& vec1) {
	for (auto i : vec1) {
		std::cout << i << " ";
	}
}

int main() {
	std::vector<double> vec{1.5};
	InputFunction iF = InputFunc1;
	OutputFunction oF = OutputFunc1;

	TMP tmp1(5, 4.0, iF, oF);

	tmp1.print();
	tmp1.computation(); //should do scalar mult by 3 from InputFunc1 above
	

	return 0;
}