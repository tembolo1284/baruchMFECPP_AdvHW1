#include <iostream>
#include <memory>

struct Base {
public:
    virtual void draw() { std::cout << "Draw a base\n"; }
    virtual void draw() const {}
    virtual void print() { std::cout << "Print from Base.\n"; }
    ~Base() { std::cout << "bye base\n"; }
};

struct Derived final : public Base {
public:
    Derived() {}
    void draw() override { std::cout << "Draw a derived\n"; }
    void draw() const override {}
    void print() override {std::cout << "Print from Derived.\n";}
    ~Derived() { std::cout << "bye derived\n"; }
};

int main() {
    std::shared_ptr<Base> dFromBase = std::shared_ptr<Base>(new Derived());

    (*dFromBase).draw();
    (*dFromBase).print();

    return 0;
}
