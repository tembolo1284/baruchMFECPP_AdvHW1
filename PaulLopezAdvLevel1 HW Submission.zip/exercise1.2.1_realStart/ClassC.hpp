
#ifndef ClassC_hpp
#define ClassC_hpp
#include <vector>
using namespace std;

class ClassC {
private:
	//ClassC(const ClassC& c) = delete; //copy constructor
	//ClassC(const ClassC& c);
	//ClassC& operator = (const ClassC& source) = delete; //assignment
	

public:
	vector<double> vec; //vector data member

    ClassC(); // = default; //default constructor
	ClassC(const ClassC& c);
	~ClassC(); //destructor
	
	ClassC& operator = (const ClassC& source);
	void print() noexcept; //print
	ClassC& operator * (const double factor) noexcept; //scalar mult of vector data member
};


#endif
