/*a) Modify class C so that 1) its default constructor is absent and 2) copy constructor and assignment are private. To this end, 
use keyword default to explicitly tell the compiler to generate a default constructor. Furthermore, use the keyword delete to mark the 
copy constructor and assignment operator as deleted functions. Deleted functions may not be used in any way, even by friends. Test your 
code again, including calling the defaulted and deleted functions. What is the resulting behavior?

the default constructor still works with defaulting, but I can't even compile now because of errors in copy constructor and assignment operators.

b) Use the explicit keyword in the constructors to disallow implicit type conversion.
copy constructor doesn't work now!

c) Use constexpr keyword for those functions in which input arguments are known at compile-time (for example, constructors and setters). 
Then the data members will also be known at compile-time.

d) Use the keyword noexcept for those member functions which you know will not throw an exception.

Run and test your code.*/

#include "ClassC.hpp"
#include <iostream>
using namespace std;

int main() {

	ClassC C1; //default constructor
	ClassC C2(C1); // copy constructor
	ClassC C3;
	double num{ 5.0 };
	cout << "Vector before scalar mult: ";
	for (int i = 0; i < C1.vec.size(); i++) {
		cout << C1.vec[i] << " ";
	}
	cout << endl;
	C1 * num;
	cout << "Vector after scalar mult: ";
	for (int i = 0; i < C1.vec.size(); i++) {
		cout << C1.vec[i] << " "; // should spit out 5 10 15
	}
	cout << endl;
	//print statement
	C1.print();
	C2.print();
	cout << endl;

	ClassC C4; 
	C4 = C2 * num; //assignment operator
	C4.print();

	return 0;

}