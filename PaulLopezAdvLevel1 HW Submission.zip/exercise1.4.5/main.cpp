#include <iostream>
#include <functional>
using namespace std;
using namespace std::placeholders;
template <typename T>
using FunctionType = std::function<T(const T& t)>;

template <typename T>
class NextGenPolymorphism {
private:
	FunctionType<T> _func;
	T _fac;
public:
	NextGenPolymorphism(const FunctionType<T>& function, const T& factor) : _fac(factor) {
		_func = function;
	}
	T execute(double d) { return _func(d) * _fac; }
	void switchFunction(const FunctionType<T>& function) {
		_func = function;
	}
};

template <typename T>
class ShapeNextGenPolymorphism {
private:
	FunctionType<T> _func;
	T _fac;
public:
	ShapeNextGenPolymorphism(const FunctionType<T>& function, const T& factor) : _fac(factor) {
		_func = function;
	}
	T rotate(double d) { return _func(d) * _fac; }

	void switchFunction(const FunctionType<T>& function) {
		_func = function;
	}
};

// Class hierarchy
class Shape {
protected:
	using VoidFunctionType = std::function<void(double)>;
	VoidFunctionType fShape; 
public:
	virtual void rotate(VoidFunctionType& f, double d) = 0;
	Shape() {} //boring default constructor

	Shape(double d) { 
		//rotate(fShape, d);
	}
};

class Circle : public Shape { //derived from shape

protected:
	using VoidFunctionType = std::function<void(double)>;
	VoidFunctionType fCircle; 

public:
	void rotate(VoidFunctionType& f, double d) override { std::cout << "circle\n"; }
	Circle(double d) {
		//rotate(fCircle, d);
	}

};

class Line : public Shape { //derived from shape
protected:
	using VoidFunctionType = std::function<void(double)>;
	VoidFunctionType fLine; 

public:
	void rotate(VoidFunctionType& f, double d) override { std::cout << "line\n"; }
	Line(double d) {
		//rotate(fLine, d);
	}
};


struct RandomClass { // Function object with extra member functions and data
	double _data;
	RandomClass(double data) : _data(data) {
	}
	double operator () (double factor) {
		return _data + factor;
	}
	double OneParam(double factor) {
		return _data + factor;
	}
	double TwoParam(double factor1, double factor2) {
		return _data + factor1 + factor2;
	}
	static double DoIt(double x) {
		return x * x;
	}
	void print() const {
		std::cout << _data;
	}
};

class C { // Function object with extra member functions
private:
	double _data;
public:
	C(double data) : _data(data) {}
	double operator () (double factor) {
		return _data + factor;
	}

	double translate(double factor) {
		return _data + factor;
	}

	double translate2(double factor1, double factor2) {
		return _data + factor1 + factor2;
	}

	static double Square(double x) {
		return x * x;
	}
};



template <typename T>
void print(const FunctionType<T>& f, T t) {
	std::cout << f(t) << '\n';
}

double freeFn(double d){
	return (d * d);
}

double freeFunction3(double x, double y, double z) {
	return (x + y + z);
}

int main() {
	using namespace std::placeholders; 
	
	using VoidFunctionType = std::function<void(double)>;
	VoidFunctionType fExternal; // for _1, _2, _3...
	double d1{ 1.0 };
	double d2{ 2.0 };

	Circle c1(d1); 
	Line l1(d2);
	c1.rotate(fExternal, d1); //using main() created f to run rotat

	//next gen goodness
	auto square = [](double d) {return d * d; };
	auto cubed = [](double d) {return d * d * d; };
	auto expo = [](double d) {return std::exp(d); };
	ShapeNextGenPolymorphism<double> sng(square, 1.0);
	std::cout << "Square: " << sng.rotate(2.0) << '\n'; // 4
	// square is not cool, switch to expo
	sng.switchFunction(expo);
	std::cout << "Exponential: " << sng.rotate(5.0) << std::endl; // 148.413 */
	sng.switchFunction(cubed);
	std::cout << "Cubed: " << sng.rotate(2.0); // 8
	//sng = shape next gen
	
	
	return 0;
}
