#include <vector>
#include <iostream>
#include <algorithm>
#include <numeric>
#include <complex>
using namespace std;

// N.B. Generic lambda
auto MyMultiply = [](auto x, auto y) { return x * y; };

struct FOMultiply {
    template <typename T>
    T operator () (const T& x, const T& y) {
        return x * y;
    }
};


int main() {

    std::vector<int> vec{ 1,2,3,4,5 };
    int initVal = 1;
    int acc2 = std::accumulate(vec.begin(), vec.end(), initVal,
        std::multiplies<int>());

    int accA = accumulate(vec.begin(), vec.end(),
        initVal, FOMultiply());

    //a) Implement and test the algorithm using the generic lambda:

    int accMyMult = accumulate(vec.begin(), vec.end(), initVal, MyMultiply);

    cout << "acc2: " << acc2 << endl;
    cout << "accA: " << accA << endl;
    cout << "accMyMult: " << accMyMult << endl << endl; //<-- generic lambda print

//(a+bi)(c+di) = ac + adi + bci + bdi2 <-- multiplication for complex numbers, a, b, c, d are real
   // => (ac-bd) + (ad+bc)i <-- can easily do this in a lambda function I think!!!

//Can the algorithm also be used with complex numbers, for example? Can we use function objects to multiply the elements of an array of complex numbers?
//b) Implement the accumulation algorithm using an embedded lambda function in combination with std::for_each() and captured variables.
    typedef complex<double> Complex;
    Complex c1(1.0, 2.0);
    Complex c2(3.0, 4.0);  
    Complex c3(5.0, 6.0);
    Complex c4(1.0, 1.0);
    Complex initComplex(1.0, 0.0); //identity for complex multiplication (a+bi)(1+0i) = (a-0) + (0+bi) => a + bi
    Complex starter(1.0, 0.0);
    
    vector<Complex> CArray1{ c1, c2 };
    vector<Complex> CArray2{ c1, c2, c3, c4 };
    cout << "Using accComplexMine part b) c1*c2*c3*c4 = " ;

    auto accComplexMine = for_each(CArray2.begin(), CArray2.end(), [&](Complex c) {starter *= c;});  
    cout << starter << endl;
   
//c) Give an example of a stored lambda function that may be called from an STL algorithm (may be any relevant STL algorithm).
//Demonstrate using the STL algorithm with your stored lambda.
    
    auto ComplexMult = [](Complex c1, Complex c2) -> Complex {return (c1 * c2);}; //my stored lambda

    auto complexAccum = accumulate(CArray2.begin(), CArray2.end(), initComplex, ComplexMult);

    cout << "\nPart c) " << complexAccum; //c1 * c2 *c3 *c4  = (-85+ 20i) (1+1i) = -105 -65i

    //I need to work on my variable and lambda naming :)
return 0;

}
