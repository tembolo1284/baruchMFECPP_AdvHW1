/*We now return to class C in exercise 1. Answer the following questions:

a) Create the move constructor and the move assignment operator for class C.
b) Test these new functions. How can you ensure that a move constructor is called instead of a copy constructor?
Definitely if a rh reference is passed in, it will call a move constructor.  Other than that my only idea
is to implement a move even for the copy constructor as move works with lh references as well.

c) What happens if you use an lvalue as the source of a move operation?.
It stills works for me. It makes it an xvalue and lets you do as you please with it. Move is a powerful guy. */

#include "ClassC.hpp"
#include <iostream>
using namespace std;

int main() {

	ClassC C1; // default constructor
	C1 = ClassC(5); //constructor with int param then move assignment
	ClassC C2 = move(C1); //move constructor
	ClassC C3(C2);
	
	return 0;

}