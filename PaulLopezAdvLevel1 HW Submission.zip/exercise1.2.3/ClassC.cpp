#include "ClassC.hpp"
#include <vector>
#include <iostream>
using namespace std;

ClassC::ClassC() : vec{1.0,2.0,3.0} {
	cout << "Default constructor." << endl;
}

ClassC::ClassC(const int n) : vec(n,n) { //create a vector of size n filled with n's
	cout << "Constructor with int param." << endl;
}

ClassC::ClassC(const ClassC& c) : vec(c.vec) {
	cout << "Copy constructor." << endl;
}//copy constructor

ClassC::ClassC(ClassC&& c) : vec(move(c.vec)) {
	cout << "Move constructor." << endl;
}

ClassC& ClassC::operator = (const ClassC& source) { // copy assignment operator.
	cout << "This is a copy assignment operator." << endl;
	if (this == &source) {
		return *this;
	}
	vec = source.vec;
	return *this;
}

ClassC& ClassC::operator = (ClassC&& source) { // move assignment operator.
	cout << "This is a move assignment operator." << endl;
	if (this == &source) {
		return *this;
	}
	vec = move(source.vec);
	for (int i = 0; i < source.vec.size(); i++) {
		source.vec[i] = NULL; //can't forget this step
	}
	return *this;
}
ClassC::~ClassC() {
	cout << "Bye Bye ClassC." << endl;
} //destructor

ClassC& ClassC::operator * (const double factor) {  // Scale the coordinates.
	vector<double> v;
	int size = vec.size();
	double forArray{ 0 };
	for (int i = 0; i < size; i++) {
		v.push_back(vec[i] * factor);
		
	}
	vec = v;
	return *this;
}

void ClassC::print() {
	cout << "\nElements of vector: ";
	int size = vec.size();
	double val{};
	for (int i = 0; i < size; i++) {
		cout << vec[i] << " ";
	}
	cout << endl;
}