
#ifndef ClassC_hpp
#define ClassC_hpp
#include <vector>
using namespace std;

class ClassC {
	
public:
	vector<double> vec; //vector data member

	ClassC(); //default constructor
	ClassC(const int n);
	ClassC(const ClassC& c); //copy constructor
	ClassC(ClassC&& c); //move constructor

	~ClassC(); //destructor
	ClassC& operator = (const ClassC& source); //copy assignment
	ClassC& operator = (ClassC&& source); //move assignment
	void print(); //print
	ClassC& operator * (const double factor); //scalar mult of vector data member
};


#endif
