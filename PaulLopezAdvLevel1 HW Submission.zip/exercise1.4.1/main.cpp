#include <iostream>
#include <functional>
using namespace std;

template <typename T>
using FunctionType = std::function<T(const T& t)>;

template <typename T>
void print(const FunctionType<T>& f, T t) {
	std::cout << f(t) << '\n';
}

double freeFn(double d){
	return (d * d);
}

int main() {
	
	FunctionType<double> f1 = freeFn;
	FunctionType<double> f2 = [&](double d) {return d * d;};
	FunctionType<double> f3 = f1;
	double num = 2.0;
	std::cout << "f1: ";
	print(f1, num);
	std::cout << "f2: ";
	print(f2, num+1.0);
	std::cout << "f3: ";
	print(f3, num+2.0);



	return 0;
}
