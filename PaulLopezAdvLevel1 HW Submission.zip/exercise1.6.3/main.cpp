#include <iostream>
#include <array>
#include<cstdio>
using namespace std;

class Example {
private:
    int n;
public:
    Example() : n(0) { std::cout << "Default ctor."; } //default ctor sets a = 0
    Example(int a) : n(a) { std::cout << "Ctor w/ int."; } //ctor with int sets n = int a param
    Example(Example& e) : n(e.n) { std::cout << "Copy ctor."; } //copy constructor
};

struct S {
    int x;
    struct Foo {
        int i; int j; int a[3];
    } b;
};
int main() {
    Example e1{}; //default init
    Example e2(2); //direct init
    Example e3(e2); //copy init
    Example e4 = 3; // another copy init
    Example e5[5] = { 7, 8, 9, 1, 2 }; //agg init or list init?
    Example& e6 = e5[0]; // ref init
    //-------------------------------------------
    std::array<int,3> c[] = {3,3,3};
    int a = 5;
    S s_ex1 = {5, {1, 2, {3,3,3}}};  //x = 5, i = 1, j = 2, a[3] = 3,3,3
    S s_ex2 = {5,1,2,3,3,3}; //should be same as above
    S s_ex3{ 5,1,2,3,3,3 }; //should be like s_ex2 
    S s_ex4{ 5, {1, 2, {3,3,3}} }; //works like s_ex1
    //S s_ex5 = { 5, {1,2,{c}}}; //<-- doesn't work for c or c[3]. Thought that should work.
    S s_ex5{ a, {1, 2, {3,3,3}} };

    S s_ex6{ 5.5, {1.125, 2, {3,3,3}} }; //compiles but precision is lost since we have ints

   
    std::cout << "done." << std::endl;

    return 0;
}






